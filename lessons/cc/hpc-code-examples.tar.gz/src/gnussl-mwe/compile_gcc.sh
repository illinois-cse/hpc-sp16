#~/usr/bin/bash
rm ./quad
module load gcc
g++ quad.cpp -lquadmath -std=c99 -o quad
